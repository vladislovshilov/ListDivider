import Foundation

public class Node<T> {
    var value: T
    var next: Node<T>?
    weak var previous: Node<T>?
    
    init(value: T) {
        self.value = value
    }
}

public class LinkedList<T> {
    private var head: Node<T>?
    private var tail: Node<T>?
    
    var isEmpty: Bool {
        return head == nil
    }
    
    var first: Node<T>? {
        return head
    }
    
    var last: Node<T>? {
        return tail
    }
    
    var count: Int {
        var index = 0
        var node = head
        
        while node != nil {
            index += 1
            node = node!.next
            if node == nil { break }
        }
        
        return index
    }
    
    func append(value: T) {
        let newNode = Node(value: value)
        if let tailNode = tail {
            newNode.previous = tailNode
            tailNode.next = newNode
        } else {
            head = newNode
        }
        tail = newNode
    }
    
    func nodeAt(index: Int) -> Node<T>? {
        if index >= 0 {
            var node = head
            var i = index
            while node != nil {
                if i == 0 { return node }
                i -= 1
                node = node!.next
            }
        }
        return nil
    }
    
    func removeAll() {
        head = nil
        tail = nil
    }
}

extension LinkedList: CustomStringConvertible {
    public var description: String {
        var text = "["
        var node = head
        
        while node != nil {
            text += "\(node!.value)"
            node = node!.next
            if node != nil { text += ", " }
        }
        
        return text + "]"
    }
}

extension LinkedList {
    func reversed() -> LinkedList<T> {
        let reversedList = LinkedList<T>()
        var node = last
        
        while node != nil {
            reversedList.append(value: node!.value)
            node = node!.previous
        }
        
        return reversedList
    }
}

final class NumbersListDivider {
    static func divideList(withHead head: Node<Int>?) -> (odd: LinkedList<Int>, even: LinkedList<Int>) {
        let oddList = LinkedList<Int>()
        let evenList = LinkedList<Int>()
        var node = head
        
        while node != nil {
            if node!.value % 2 == 0 {
                evenList.append(value: node!.value)
            }
            else {
                oddList.append(value: node!.value)
            }
            
            node = node!.next
            if node == nil { break }
        }
        
        return (oddList, evenList)
    }
    
    static func divideAndReverseList(withHead head: Node<Int>?) -> (odd: LinkedList<Int>, even: LinkedList<Int>) {
        let dividedList = divideList(withHead: head)
        return (dividedList.odd.reversed(), dividedList.even.reversed())
    }
}

let numbersList = LinkedList<Int>()
numbersList.append(value: 1)
numbersList.append(value: 2)
numbersList.append(value: 3)
numbersList.append(value: 4)
numbersList.append(value: 5)
numbersList.append(value: 6)
numbersList.append(value: 7)
numbersList.append(value: 8)
numbersList.append(value: 9)

print(numbersList.description)

let reversedList = NumbersListDivider.divideAndReverseList(withHead: numbersList.first)
print(reversedList.even.description)
print(reversedList.odd.description)
